var Objdata = [
    {
        email: "carstoveanu55@gmail.com",
        password: "123"
    },
    {
        email: "carstoveanud@gmail.com",
        password: "123"
    },
    {
        email: "carstoveanugheorghe@gmail.com",
        password: "123"
    },
]

function Style_mod(style_mod,style_elem){
    const myStyle= style_mod;
    const element = document.querySelector(style_elem);
    element.style.cssText= myStyle;
}

function GetInfo(){
    var email = document.getElementById("email").value
    var password = document.getElementById("password").value
    
    for(i=0;i<Objdata.length;i++)
    {
        if (email=="" || password==""){
            Style_mod('margin-top: 20px; ','.btnn')
            Style_mod('height: 410px;','.form')
            Style_mod('margin-top: 20px;','.errorlog')
            var error_login="These two fields are mandatory."
            document.getElementById('output').innerHTML = error_login;
        }
        else if (email==Objdata[i].email && password==Objdata[i].password){
            var error_login="The account is valid"
            document.getElementById('output').innerHTML = error_login;
            break
        }
        else {
            Style_mod('margin-top: 20px; ','.btnn')
            Style_mod('height: 410px;','.form')
            Style_mod('margin-top: 20px;','.errorlog')
            var error_login="Wrong password or e-mail."
            document.getElementById('output').innerHTML = error_login;
        }
        
    }
}